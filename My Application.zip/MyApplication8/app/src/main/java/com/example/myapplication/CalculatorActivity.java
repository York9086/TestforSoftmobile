package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {

    private EditText edn;
    private Button bt0,bt1,bt2,bt3,bt4,bt5,bt6,bt7,bt8,bt9,btp,btde,btdv,btper,btt,btdt,bte,btc,
            btf;
    private int initial =0;//用於判斷的變數，判斷現在輸入的數字是否為0以外的數字
    //若數字為0或在按下了運算符號後須重新輸入數字時，initial會等於0
    //否則在未輸入數字的狀態下按兩次以上的0就會變成00000。所以只有在需要重新輸入一組數字時才會為0。其他時候為1，來讓我們能
    //夠正常的在數字中輸入0。
    private int sig=0;//代表運算符號的變數，1~4分別代表加減乘除。
    private double ans=0;//答案，因為有小數點功能所以宣告為doule
    private String str1,str2;//計算機進行運算時的運算數(str1)與被運算數(str2)，即為按下運算符號前後的兩個數字。
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        //以下為宣告各個按鍵會透過id連結到xml檔中的哪些按鍵
        edn = findViewById(R.id.edittextnum);//用來顯示數字的view
        bt0 = findViewById(R.id.button0);
        bt1 = findViewById(R.id.button1);
        bt2 = findViewById(R.id.button2);
        bt3 = findViewById(R.id.button3);
        bt4 = findViewById(R.id.button4);
        bt5 = findViewById(R.id.button5);
        bt6 = findViewById(R.id.button6);
        bt7 = findViewById(R.id.button7);
        bt8 = findViewById(R.id.button8);
        bt9 = findViewById(R.id.button9);//0~9為數字按鈕
        btp = findViewById(R.id.buttonplus);//加
        btde = findViewById(R.id.buttonde);//減
        btdv = findViewById(R.id.buttondiv);//除
        btper = findViewById(R.id.buttonper);//百分
        btt = findViewById(R.id.buttontimes);//乘
        btdt = findViewById(R.id.buttondot);//小數點
        bte = findViewById(R.id.buttoneq);//等於
        btc = findViewById(R.id.buttonAC);//歸零
        btf = findViewById(R.id.buttonfac);//階乘

        //下列為按下按鈕時觸發onClick函式
        bt0.setOnClickListener(this::onClick);
        bt1.setOnClickListener(this::onClick);
        bt2.setOnClickListener(this::onClick);
        bt3.setOnClickListener(this::onClick);
        bt4.setOnClickListener(this::onClick);
        bt5.setOnClickListener(this::onClick);
        bt6.setOnClickListener(this::onClick);
        bt7.setOnClickListener(this::onClick);
        bt8.setOnClickListener(this::onClick);
        bt9.setOnClickListener(this::onClick);//0~9為數字按鈕
        btdt.setOnClickListener(this::onClick);//小數點
        btp.setOnClickListener(this::onClick);//加
        bte.setOnClickListener(this::onClick);//等於
        btde.setOnClickListener(this::onClick);//減
        btt.setOnClickListener(this::onClick);//乘
        btdv.setOnClickListener(this::onClick);//除
        btc.setOnClickListener(this::onClick);//歸零
        btper.setOnClickListener(this::onClick);//百分
        btf.setOnClickListener(this::onClick);//階乘
        
    }
    public void factorial(String strf){//存放階乘運算的函式
        int faccount = Integer.parseInt(strf);//傳入計算機所按的值(strf)並轉為整數型別(階乘不能運算小數)
        int facans=1;//宣告用於存放答案的整數。同時也以此數作為首項，則為1。
        if(faccount!=0){//若輸入的數字為0時，計算機會顯示答案為1。但下面的迴圈不會讓0跑進去，所以另外寫一if，來判斷
            //輸入數字為0的結果。而讓他在為0的時候直接以首項1印出即為答案，因此在以下迴圈寫為0以外的數字才能傳入。
            for(int i=1;i<=faccount;i++){//從數字1(facans=1)開始乘到計算機所輸入的數字(faccount)。
                facans=i*facans;
            }
        }
        edn.setText(String.valueOf(facans));//在將答案改為字串並在view中顯示
    }

    public void onClick(View v){//按下案件所觸發的函式
        if(v.getId()!=R.id.buttonAC){//此計算機參考對象為ios計算機，按下其他按鍵時，AC按鍵會變為C，要再按C才會變回
            btc.setText("C");//讓按下AC/C以外按鍵時，讓按鍵變為C
        }
        switch (v.getId()){//以switch來讓不同按鍵被按下時會觸發不同結果。
            case R.id.buttonAC:
                //歸零時view中顯示為0，存放前後項(str1、2)的數字、運算符號也清空不能保留
                //要重新輸入數字，view中只有0的狀態下不能再輸入0，所以initial也為0。
                edn.setText("0");
                str1="";
                str2="";
                sig=0;
                initial=0;
                btc.setText("AC");//最後按鍵如果為C時，按下C要讓按鍵變回AC
                break;
            case R.id.button0://0
                //前面提過如果initial是0的話，不能讓數字0後面又出現0(如00)，所以
                if(initial!=0){//initial不是0的時候，讓數字0可以出現在其他數字後面
                    edn.setText(edn.getText()+bt0.getText().toString());
                    initial = 1;
                }else if(initial==0){//initial為0時，代表view中數字為0，0後面則不可再出現0，所以直接項view中數
                    //字重設為0
                    edn.setText("0");
                }
                break;
            case R.id.button1://1
                if(initial==0){//若數字為0或在按下了運算符號後須重新輸入數字時，initial會等於0
                    // 這時輸入數字1時，view中顯示應該從0變為1。
                    edn.setText(bt1.getText().toString());
                    initial = 1;
                }else{//initial會等於1，則直接在該數字後面加上1就好。(其餘數字皆為相同模式)
                    // (如：view中已有數字2，按下1後會變為21)
                    edn.setText(edn.getText()+bt1.getText().toString());
                }
                break;
            case R.id.button2://2
                if(initial==0){
                    edn.setText(bt2.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt2.getText().toString());
                }
                break;
            case R.id.button3://3
                if(initial==0){
                    edn.setText(bt3.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt3.getText().toString());
                }
                break;
            case R.id.button4://4
                if(initial==0){
                    edn.setText(bt4.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt4.getText().toString());
                }
                break;
            case R.id.button5://5
                if(initial==0){
                    edn.setText(bt5.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt5.getText().toString());
                }
                break;
            case R.id.button6://6
                if(initial==0){
                    edn.setText(bt6.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt6.getText().toString());
                }
                break;
            case R.id.button7://7
                if(initial==0){
                    edn.setText(bt7.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt7.getText().toString());
                }
                break;
            case R.id.button8://8
                if(initial==0){
                    edn.setText(bt8.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt8.getText().toString());
                }
                break;
            case R.id.button9://9
                if(initial==0){
                    edn.setText(bt9.getText().toString());
                    initial = 1;
                }else{
                    edn.setText(edn.getText()+bt9.getText().toString());
                }
                break;
            case R.id.buttondot://小數點
                if(initial==0){//和其他數字一樣，view內為0時要直接在後面加上小數點
                    edn.setText("0"+btdt.getText().toString());//按下運算符號後，view中可能會顯示其他的數字
                    //但這時候不能讓小數點直接顯示在前一數字後面，所以要另外重新顯是一個0+小數點。
                    initial = 1;
                    //小數點只會出現一個不然就會發生0.....1423這種狀況(正常為0.1432)。所以不像數字要另外去設出現
                    //第二次數字的狀況
                }
                break;
            case R.id.buttonplus://加法
                str1=edn.getText().toString();//按下運算符號時，紀錄按下符號前view中的數字，記在str1
                sig=1;//sig為1時是加法，這樣在按下等於按鍵時才能夠判斷按下了哪個運算符號。若按過別的運算符號時
                //也會在這裡被更新掉。
                initial=0;//按下運算符號後需要輸入別的數字，所以initial也要歸0了，不然按下的數字會直接加在前一項後面
                //運算符號的邏輯皆與此相同

                break;
            case R.id.buttonde://減法
                str1=edn.getText().toString();
                sig=2;//sig為2時為減法
                initial=0;

                break;
            case R.id.buttontimes://乘法
                str1=edn.getText().toString();
                sig=3;//sig為3時為乘法
                initial=0;
                break;
            case R.id.buttondiv://除法
                str1=edn.getText().toString();
                sig=4;//sig為4時為除法
                initial=0;
                break;
            case R.id.buttonfac://階乘
                str1=edn.getText().toString();
                factorial(str1);//不會有第二項，所以直接拿第一項丟進階乘函式factorial中
                initial=0;
                break;
            case R.id.buttoneq://等於
                str2=edn.getText().toString();//在按下運算符號後就能輸入第二次數字，這時候輸入的數字在按下等於時
                //會存入str2中。
                if(sig==1){//sig為1時為加法
                    ans=Double.valueOf(str1)+Double.valueOf(str2);//因為可能有小數點所以轉為double再運算
                    if(ans%1==0){//如果能被1整除代表此數字為整數，此判斷目的為讓答案為整數時，讓view中不會出現多餘的
                        //小數點後為0的部分(因為型態為double，在下一行轉為字串時會把小數點一起轉進去，所以小數點後為
                        // 0的部分會一起顯示出來)
                        edn.setText(String.format("%.0f",ans));//轉為字串，讓小數點後為0的部分不顯示
                    }else{//不是整數的話就是小數了，就正常轉為字串印出來
                        edn.setText(String.valueOf(ans));
                    }
                    sig=0;//讓運算符號的變數歸零，以便進行下一次運算。
                    //後續運算符號邏輯皆與此相同。唯有計算ans的加減乘除不同
                }else if(sig==2){//sig為2時為減法
                    ans=Double.valueOf(str1)-Double.valueOf(str2);
                    if(ans%1==0){
                        edn.setText(String.format("%.0f",ans));
                    }else{
                        edn.setText(String.valueOf(ans));
                    }
                    sig=0;
                }else if(sig==3){//sig為3時為乘法
                    ans=Double.valueOf(str1)*Double.valueOf(str2);
                    if(ans%1==0){
                        edn.setText(String.format("%.0f",ans));
                    }else{
                        edn.setText(String.valueOf(ans));
                    }
                    sig=0;
                }else if(sig==4){//sig為4時為除法
                    ans=Double.valueOf(str1)/Double.valueOf(str2);
                    if(ans%1==0){
                        edn.setText(String.format("%.0f",ans));
                    }else{
                        edn.setText(String.valueOf(ans));
                    }
                    sig=0;
                }
                initial=0;//按下等於後要能輸入下一組數字，initial要歸0
                break;
            case R.id.buttonper://百分比，乘以0.01
                str1=edn.getText().toString();
                ans=Double.valueOf(str1)*0.01;
                if(ans%1==0){
                    edn.setText(String.format("%.0f",ans));
                }else{
                    edn.setText(String.valueOf(ans));
                }
                initial=0;
                break;
        }
    }
}