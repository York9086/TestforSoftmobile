package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.inputmethodservice.Keyboard;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {

    private EditText edittext1;//用於填寫姓名的Edittext
    private Button confirm;//按下後會跳轉到計算機介面的按鍵

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edittext1=findViewById(R.id.edittext1);
        confirm=findViewById(R.id.button);
        confirm.setOnClickListener(this::onClick);//監聽confirm按鍵，讓他被按下時執行onclick中的指令
        confirm.setEnabled(false);//在此專案中設計為輸入名稱後才能按下confirm，所以預設讓confirm不能按，輸入名稱
        // 的edittextview中有內容時再讓他能夠被按下。
        edittext1.addTextChangedListener(new TextWatcher() {//設立監聽，監聽edittext1的狀態是否發生改變。
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {

            }

            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                //讓edittext內容發生變化時進行按鈕狀態改變
                if (TextUtils.isEmpty(edittext1.getText())) {//view中內容變為空時(gettext為empty時)
                    confirm.setEnabled(false);//讓按鍵無法被按
            }else {
                    confirm.setEnabled(true);//此外讓按鍵能夠被按。
                }

        }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
    public void onClick(View view){//按下按鈕後跳轉到另一Activity，為此建立的函式。
        Intent intent = new Intent(this,CalculatorActivity.class);//宣告Intent指向計算機
        //所在的介面：CalculatorActivity
        startActivity(intent);//打開Activity CalculatorActivity
    }
}